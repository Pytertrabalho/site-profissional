import React from 'react';
import { Star, Quote, TrendingUp, Users } from 'lucide-react';

const Testimonials = () => {
  const testimonials = [
    {
      name: 'Maria Santos',
      business: 'Loja de Roupas Femininas',
      image: 'https://images.pexels.com/photos/1036623/pexels-photo-1036623.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
      content: 'Depois de 30 dias com a Avanço Digital, meu faturamento dobrou. A loja ficou incrível e os clientes não param de elogiar. Recomendo de olhos fechados!',
      result: '+120% em vendas',
      rating: 5
    },
    {
      name: 'Carlos Oliveira',
      business: 'Restaurante Local',
      image: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
      content: 'O Pedro transformou nosso delivery. Agora temos um sistema completo e os pedidos triplicaram. A equipe é muito profissional e atenciosa.',
      result: '+200% em pedidos',
      rating: 5
    },
    {
      name: 'Ana Ferreira',
      business: 'Clínica de Estética',
      image: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&fit=crop',
      content: 'O Marcus revolucionou nossa presença digital. Os anúncios estão trazendo clientes qualificados todos os dias. Valeu cada centavo investido!',
      result: '+150% em agendamentos',
      rating: 5
    }
  ];

  const stats = [
    {
      number: '50+',
      label: 'Negócios transformados',
      icon: Users
    },
    {
      number: '200%',
      label: 'Aumento médio em vendas',
      icon: TrendingUp
    },
    {
      number: '30',
      label: 'Dias para ver resultados',
      icon: Star
    }
  ];

  return (
    <section className="py-12 sm:py-16 lg:py-20 bg-gradient-to-br from-blue-900 via-indigo-900 to-purple-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12 sm:mb-16">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4 sm:mb-6">
            Depoimentos e <span className="text-orange-400">Resultados</span>
          </h2>
          <p className="text-lg sm:text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed px-4">
            Veja como outros empresários transformaram seus negócios com a Avanço Digital
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid md:grid-cols-3 gap-6 sm:gap-8 mb-12 sm:mb-16">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 sm:p-8 hover:bg-white/20 transition-all duration-300">
                <div className="bg-orange-500 w-12 h-12 sm:w-16 sm:h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <stat.icon className="text-white" size={24} />
                </div>
                <div className="text-3xl sm:text-4xl font-bold text-white mb-2">{stat.number}</div>
                <div className="text-gray-300 text-base sm:text-lg">{stat.label}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Testimonials Grid */}
        <div className="grid lg:grid-cols-3 gap-6 sm:gap-8 mb-12 sm:mb-16">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-white rounded-2xl shadow-xl p-6 sm:p-8 hover:shadow-2xl transition-all duration-300 hover:scale-105">
              {/* Quote Icon */}
              <div className="flex justify-between items-start mb-6">
                <Quote className="text-blue-600 opacity-20 flex-shrink-0" size={40} />
                <div className="flex gap-1">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="text-yellow-400 fill-current" size={16} />
                  ))}
                </div>
              </div>

              {/* Testimonial Content */}
              <p className="text-gray-600 text-base sm:text-lg leading-relaxed mb-6 italic">
                "{testimonial.content}"
              </p>

              {/* Result Badge */}
              <div className="bg-green-100 text-green-800 px-3 sm:px-4 py-1 sm:py-2 rounded-full text-xs sm:text-sm font-semibold mb-6 inline-block">
                {testimonial.result}
              </div>

              {/* Author Info */}
              <div className="flex items-center gap-4">
                <img
                  src={testimonial.image}
                  alt={testimonial.name}
                  className="w-12 h-12 sm:w-16 sm:h-16 rounded-full object-cover flex-shrink-0"
                />
                <div>
                  <h4 className="font-bold text-gray-900 text-base sm:text-lg">{testimonial.name}</h4>
                  <p className="text-gray-600 text-sm sm:text-base">{testimonial.business}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Success Stories CTA */}
        <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 sm:p-8 lg:p-12 text-center mb-12 sm:mb-16">
          <h3 className="text-2xl sm:text-3xl font-bold text-white mb-4">
            Seu negócio pode ser o próximo caso de sucesso
          </h3>
          <p className="text-lg sm:text-xl text-gray-300 mb-6 sm:mb-8 max-w-2xl mx-auto px-4">
            Junte-se a mais de 50 empresários que já transformaram seus negócios com nossa ajuda
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <a
              href="#especialistas"
              className="bg-orange-500 hover:bg-orange-600 text-white px-6 sm:px-8 py-3 sm:py-4 rounded-full font-semibold text-base sm:text-lg transition-all duration-300 hover:scale-105 flex items-center gap-3 w-full sm:w-auto justify-center"
            >
              <TrendingUp size={18} />
              <span className="text-sm sm:text-base">Transformar meu negócio agora</span>
            </a>
            
            <a
              href="#planos"
              className="text-white hover:text-orange-400 font-medium text-base sm:text-lg transition-colors duration-300 flex items-center gap-2 justify-center"
            >
              Ver nossos planos
            </a>
          </div>
        </div>

        {/* Trust Indicators */}
        <div className="text-center">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="text-xl sm:text-2xl font-bold text-white mb-2">100%</div>
              <div className="text-gray-300 text-xs sm:text-sm">Taxa de satisfação</div>
            </div>
            <div className="text-center">
              <div className="text-xl sm:text-2xl font-bold text-white mb-2">24/7</div>
              <div className="text-gray-300 text-xs sm:text-sm">Suporte disponível</div>
            </div>
            <div className="text-center">
              <div className="text-xl sm:text-2xl font-bold text-white mb-2">30 dias</div>
              <div className="text-gray-300 text-xs sm:text-sm">Garantia total</div>
            </div>
            <div className="text-center">
              <div className="text-xl sm:text-2xl font-bold text-white mb-2">5 anos</div>
              <div className="text-gray-300 text-xs sm:text-sm">De experiência</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;