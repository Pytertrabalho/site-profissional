import React from 'react';
import { MessageCircle, Mail, MapPin, Clock, Instagram, Facebook, Linkedin, ArrowUp } from 'lucide-react';

const Footer = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleWhatsAppClick = () => {
    const message = 'Olá! Gostaria de saber mais sobre os serviços da Avanço Digital.';
    const whatsAppUrl = `https://wa.me/5511999999999?text=${encodeURIComponent(message)}`;
    window.open(whatsAppUrl, '_blank');
  };

  const quickLinks = [
    { name: 'Início', href: '#inicio' },
    { name: 'Quem Somos', href: '#quem-somos' },
    { name: 'Especialistas', href: '#especialistas' },
    { name: 'Planos', href: '#planos' }
  ];

  const services = [
    'Criação de Lojas Virtuais',
    'Gestão de Tráfego Pago',
    'Marketing Digital',
    'Conteúdo para Redes Sociais',
    'Automação de Vendas',
    'Consultoria Estratégica'
  ];

  const socialLinks = [
    { 
      name: 'Instagram', 
      icon: Instagram, 
      url: 'https://instagram.com/avancodigital',
      color: 'hover:text-pink-500' 
    },
    { 
      name: 'Facebook', 
      icon: Facebook, 
      url: 'https://facebook.com/avancodigital',
      color: 'hover:text-blue-500' 
    },
    { 
      name: 'LinkedIn', 
      icon: Linkedin, 
      url: 'https://linkedin.com/company/avancodigital',
      color: 'hover:text-blue-600' 
    }
  ];

  return (
    <footer id="contato" className="bg-gray-900 text-white">
      {/* Main Footer Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
        <div className="grid lg:grid-cols-4 md:grid-cols-2 gap-6 sm:gap-8">
          {/* Company Info */}
          <div className="lg:col-span-1">
            <div className="mb-6">
              <div className="text-2xl sm:text-3xl font-bold text-white mb-2">
                Avanço <span className="text-orange-500">Digital</span>
              </div>
              <p className="text-gray-400 leading-relaxed text-sm sm:text-base">
                Especialistas em transformar negócios locais em verdadeiros impérios digitais. 
                Sua presença online começa aqui.
              </p>
            </div>

            {/* Social Links */}
            <div className="flex gap-4">
              {socialLinks.map((social, index) => (
                <a
                  key={index}
                  href={social.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center transition-all duration-300 hover:scale-110 ${social.color}`}
                >
                  <social.icon size={18} />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg sm:text-xl font-bold text-white mb-4 sm:mb-6">Links Rápidos</h3>
            <ul className="space-y-2 sm:space-y-3">
              {quickLinks.map((link, index) => (
                <li key={index}>
                  <a
                    href={link.href}
                    className="text-gray-400 hover:text-orange-500 transition-colors duration-300 flex items-center gap-2 text-sm sm:text-base"
                  >
                    <div className="w-1 h-1 bg-orange-500 rounded-full"></div>
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-lg sm:text-xl font-bold text-white mb-4 sm:mb-6">Nossos Serviços</h3>
            <ul className="space-y-2 sm:space-y-3">
              {services.map((service, index) => (
                <li key={index} className="text-gray-400 flex items-center gap-2 text-sm sm:text-base">
                  <div className="w-1 h-1 bg-blue-500 rounded-full flex-shrink-0"></div>
                  {service}
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg sm:text-xl font-bold text-white mb-4 sm:mb-6">Contato</h3>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <MessageCircle className="text-green-500 mt-1 flex-shrink-0" size={18} />
                <div>
                  <p className="text-gray-400 text-xs sm:text-sm">WhatsApp</p>
                  <button
                    onClick={handleWhatsAppClick}
                    className="text-white hover:text-green-500 transition-colors duration-300 font-medium text-sm sm:text-base"
                  >
                    (11) 99999-9999
                  </button>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Mail className="text-blue-500 mt-1 flex-shrink-0" size={18} />
                <div>
                  <p className="text-gray-400 text-xs sm:text-sm">E-mail</p>
                  <a
                    href="mailto:contato@avancodigital.com.br"
                    className="text-white hover:text-blue-500 transition-colors duration-300 text-sm sm:text-base break-all"
                  >
                    contato@avancodigital.com.br
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <MapPin className="text-orange-500 mt-1 flex-shrink-0" size={18} />
                <div>
                  <p className="text-gray-400 text-xs sm:text-sm">Localização</p>
                  <p className="text-white text-sm sm:text-base">São Paulo, SP</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Clock className="text-teal-500 mt-1 flex-shrink-0" size={18} />
                <div>
                  <p className="text-gray-400 text-xs sm:text-sm">Atendimento</p>
                  <p className="text-white text-sm sm:text-base">Seg à Sex: 8h às 18h</p>
                  <p className="text-gray-400 text-xs sm:text-sm">Sáb: 8h às 12h</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="mt-12 sm:mt-16 pt-6 sm:pt-8 border-t border-gray-800">
          <div className="bg-gradient-to-r from-blue-600 to-teal-600 rounded-2xl p-6 sm:p-8 text-center">
            <h3 className="text-xl sm:text-2xl font-bold text-white mb-4">
              Pronto para transformar seu negócio?
            </h3>
            <p className="text-blue-100 mb-6 max-w-2xl mx-auto text-sm sm:text-base px-2">
              Fale com nossos especialistas agora e descubra como podemos fazer seu negócio crescer no digital
            </p>
            <button
              onClick={handleWhatsAppClick}
              className="bg-white text-blue-600 hover:bg-gray-50 px-6 sm:px-8 py-3 sm:py-4 rounded-full font-semibold text-base sm:text-lg transition-all duration-300 hover:scale-105 flex items-center gap-3 mx-auto"
            >
              <MessageCircle size={18} />
              <span className="text-sm sm:text-base">Falar com especialista agora</span>
            </button>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-gray-800 py-4 sm:py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="text-gray-400 text-xs sm:text-sm text-center md:text-left">
            © 2024 Avanço Digital. Todos os direitos reservados. | 
            <span className="text-gray-500"> CNPJ: 00.000.000/0001-00</span>
          </div>
          
          <div className="flex items-center gap-4 sm:gap-6">
            <a href="#" className="text-gray-400 hover:text-white text-xs sm:text-sm transition-colors duration-300">
              Política de Privacidade
            </a>
            <a href="#" className="text-gray-400 hover:text-white text-xs sm:text-sm transition-colors duration-300">
              Termos de Uso
            </a>
            <button
              onClick={scrollToTop}
              className="bg-orange-500 hover:bg-orange-600 text-white w-8 h-8 sm:w-10 sm:h-10 rounded-full flex items-center justify-center transition-all duration-300 hover:scale-110"
              aria-label="Voltar ao topo"
            >
              <ArrowUp size={16} />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;