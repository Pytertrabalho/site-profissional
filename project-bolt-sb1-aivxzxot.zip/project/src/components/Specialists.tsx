import React from 'react';
import { MessageCircle, ShoppingCart, TrendingUp, ArrowRight } from 'lucide-react';

const Specialists = () => {
  const specialists = [
    {
      name: 'Pedro Emanuel',
      role: 'Criação de Loja + Estrutura Digital',
      image: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
      specialties: [
        'Lojas virtuais otimizadas',
        'Estrutura completa do negócio',
        'Automação de vendas',
        'Integração de pagamentos'
      ],
      whatsapp: '+5511999999999',
      description: 'Especialista em transformar seu negócio em uma máquina de vendas online',
      color: 'blue'
    },
    {
      name: 'Marcus Silva',
      role: 'Tráfego + Conteúdo Digital',
      image: 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
      specialties: [
        'Gestão de tráfego pago',
        'Criação de conteúdo',
        'Posicionamento de marca',
        'Análise de resultados'
      ],
      whatsapp: '+5511888888888',
      description: 'Especialista em fazer sua marca ser vista pelas pessoas certas',
      color: 'orange'
    }
  ];

  const handleWhatsAppClick = (phone: string, name: string) => {
    const message = `Olá! Gostaria de falar com ${name} sobre os serviços da Avanço Digital.`;
    const whatsAppUrl = `https://wa.me/${phone.replace(/\D/g, '')}?text=${encodeURIComponent(message)}`;
    window.open(whatsAppUrl, '_blank');
  };

  return (
    <section id="especialistas" className="py-12 sm:py-16 lg:py-20 bg-gradient-to-br from-gray-900 via-blue-900 to-teal-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12 sm:mb-16">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4 sm:mb-6">
            Escolha Seu <span className="text-orange-400">Especialista</span>
          </h2>
          <p className="text-lg sm:text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed px-4">
            Cada especialista tem expertise única. Escolha aquele que melhor atende às necessidades do seu negócio
          </p>
        </div>

        {/* Specialists Grid */}
        <div className="grid lg:grid-cols-2 gap-6 sm:gap-8 lg:gap-12 mb-12 sm:mb-16">
          {specialists.map((specialist, index) => (
            <div key={index} className="bg-white rounded-2xl shadow-2xl overflow-hidden hover:shadow-3xl transition-all duration-300 hover:scale-105">
              {/* Specialist Image */}
              <div className="relative h-48 sm:h-64 overflow-hidden">
                <img
                  src={specialist.image}
                  alt={specialist.name}
                  className="w-full h-full object-cover"
                />
                <div className={`absolute inset-0 bg-gradient-to-t ${
                  specialist.color === 'blue' 
                    ? 'from-blue-900/80 to-transparent' 
                    : 'from-orange-900/80 to-transparent'
                }`}></div>
                <div className="absolute bottom-4 left-4 sm:left-6 text-white">
                  <h3 className="text-xl sm:text-2xl font-bold mb-1">{specialist.name}</h3>
                  <p className="text-gray-200 font-medium text-sm sm:text-base">{specialist.role}</p>
                </div>
              </div>

              {/* Specialist Content */}
              <div className="p-6 sm:p-8">
                <p className="text-gray-600 text-base sm:text-lg mb-6 leading-relaxed">
                  {specialist.description}
                </p>

                {/* Specialties */}
                <div className="mb-6 sm:mb-8">
                  <h4 className="text-base sm:text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                    {specialist.color === 'blue' ? (
                      <ShoppingCart className="text-blue-600 flex-shrink-0" size={18} />
                    ) : (
                      <TrendingUp className="text-orange-600 flex-shrink-0" size={18} />
                    )}
                    Especialidades:
                  </h4>
                  <div className="grid grid-cols-1 gap-3">
                    {specialist.specialties.map((specialty, idx) => (
                      <div key={idx} className="flex items-center gap-2">
                        <div className={`w-2 h-2 rounded-full flex-shrink-0 ${
                          specialist.color === 'blue' ? 'bg-blue-500' : 'bg-orange-500'
                        }`}></div>
                        <span className="text-gray-600 text-sm sm:text-base">{specialty}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* CTA Button */}
                <button
                  onClick={() => handleWhatsAppClick(specialist.whatsapp, specialist.name)}
                  className={`w-full ${
                    specialist.color === 'blue'
                      ? 'bg-blue-600 hover:bg-blue-700'
                      : 'bg-orange-600 hover:bg-orange-700'
                  } text-white py-3 sm:py-4 px-6 rounded-xl font-semibold text-base sm:text-lg transition-all duration-300 hover:scale-105 flex items-center justify-center gap-3 shadow-lg`}
                >
                  <MessageCircle size={18} />
                  <span className="hidden sm:inline">Quero falar com {specialist.name.split(' ')[0]}</span>
                  <span className="sm:hidden">Falar com {specialist.name.split(' ')[0]}</span>
                  <ArrowRight size={18} />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="text-center">
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 sm:p-8 max-w-2xl mx-auto">
            <h3 className="text-xl sm:text-2xl font-bold text-white mb-4">
              Não sabe qual especialista escolher?
            </h3>
            <p className="text-gray-300 mb-6 text-sm sm:text-base px-2">
              Fale conosco e ajudaremos você a escolher o melhor caminho para seu negócio
            </p>
            <button
              onClick={() => handleWhatsAppClick('+5511777777777', 'a equipe da Avanço Digital')}
              className="bg-teal-500 hover:bg-teal-600 text-white px-6 sm:px-8 py-3 sm:py-4 rounded-full font-semibold text-base sm:text-lg transition-all duration-300 hover:scale-105 flex items-center gap-3 mx-auto"
            >
              <MessageCircle size={18} />
              Falar com a equipe
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Specialists;