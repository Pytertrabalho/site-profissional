import React from 'react';
import { ArrowRight, Play } from 'lucide-react';

const Hero = () => {
  const scrollToNext = () => {
    const nextSection = document.getElementById('quem-somos');
    if (nextSection) {
      nextSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="inicio" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-900 via-blue-800 to-teal-700">
        <div className="absolute inset-0 bg-black/30"></div>
        <img
          src="https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop"
          alt="Professional workspace"
          className="w-full h-full object-cover mix-blend-overlay opacity-20"
        />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center pt-16 sm:pt-20">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-7xl font-bold text-white mb-4 sm:mb-6 leading-tight">
            Avance com <span className="text-orange-400">confiança</span>
            <br />
            Transforme sua marca no <span className="text-teal-300">digital</span>
          </h1>
          
          <p className="text-lg sm:text-xl lg:text-2xl text-blue-100 mb-6 sm:mb-8 font-light leading-relaxed max-w-3xl mx-auto px-2">
            Especialistas em criar lojas virtuais, gerenciar tráfego e conteúdo digital 
            para negócios locais que querem crescer online
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8 sm:mb-12 px-4">
            <a
              href="#especialistas"
              className="bg-orange-500 hover:bg-orange-600 text-white px-6 sm:px-8 py-3 sm:py-4 rounded-full font-semibold text-base sm:text-lg transition-all duration-300 hover:scale-105 flex items-center gap-3 shadow-2xl w-full sm:w-auto justify-center"
            >
              <span className="text-sm sm:text-base">Escolher meu especialista</span>
              <ArrowRight size={18} />
            </a>
            
            <button className="text-white hover:text-teal-300 font-medium text-base sm:text-lg transition-colors duration-300 flex items-center gap-3 w-full sm:w-auto justify-center">
              <div className="w-10 sm:w-12 h-10 sm:h-12 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center hover:bg-white/30 transition-all duration-300">
                <Play size={14} className="ml-1" />
              </div>
              <span className="text-sm sm:text-base">Ver como funciona</span>
            </button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 sm:gap-8 max-w-2xl mx-auto px-4">
            <div className="text-center bg-white/10 backdrop-blur-sm rounded-xl p-4 sm:p-6">
              <div className="text-2xl sm:text-3xl font-bold text-white mb-1 sm:mb-2">50+</div>
              <div className="text-blue-200 text-sm sm:text-base">Negócios transformados</div>
            </div>
            <div className="text-center bg-white/10 backdrop-blur-sm rounded-xl p-4 sm:p-6">
              <div className="text-2xl sm:text-3xl font-bold text-white mb-1 sm:mb-2">200%</div>
              <div className="text-blue-200 text-sm sm:text-base">Aumento médio em vendas</div>
            </div>
            <div className="text-center bg-white/10 backdrop-blur-sm rounded-xl p-4 sm:p-6">
              <div className="text-2xl sm:text-3xl font-bold text-white mb-1 sm:mb-2">30 dias</div>
              <div className="text-blue-200 text-sm sm:text-base">Para ver resultados</div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <button
        onClick={scrollToNext}
        className="absolute bottom-4 sm:bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce cursor-pointer group"
        aria-label="Rolar para próxima seção"
      >
        <div className="w-6 sm:w-8 h-10 sm:h-12 border-2 border-white/40 rounded-full flex flex-col items-center justify-start p-1 sm:p-2 group-hover:border-white/60 transition-colors duration-300">
          <div className="w-1 h-2 sm:h-3 bg-white/60 rounded-full animate-pulse group-hover:bg-white/80 transition-colors duration-300"></div>
        </div>
      </button>
    </section>
  );
};

export default Hero;