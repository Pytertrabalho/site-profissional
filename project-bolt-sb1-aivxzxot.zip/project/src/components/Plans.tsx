import React from 'react';
import { Check, Star, MessageCircle, Zap, Shield, TrendingUp } from 'lucide-react';

const Plans = () => {
  const plans = [
    {
      name: 'Plano Mensal',
      period: 'Mensal',
      popular: false,
      features: [
        'Criação de loja virtual completa',
        'Configuração de pagamentos',
        'Design responsivo profissional',
        'SEO básico otimizado',
        'Suporte técnico via WhatsApp',
        'Relatório mensal de performance',
        'Tráfego pago básico (até R$ 500)',
        'Conteúdo para redes sociais (8 posts)'
      ],
      color: 'gray'
    },
    {
      name: 'Plano Semestral',
      period: 'Semestral',
      popular: true,
      features: [
        'Tudo do plano mensal incluído',
        'Automação de marketing avançada',
        'E-mail marketing profissional',
        'Integração com WhatsApp Business',
        'Otimização contínua da loja',
        'Campanhas de remarketing',
        'Tráfego pago ampliado (até R$ 1.500)',
        'Conteúdo premium (15 posts + stories)',
        'Consultoria estratégica mensal',
        'Suporte prioritário 24/7'
      ],
      color: 'blue'
    },
    {
      name: 'Plano Anual',
      period: 'Anual',
      popular: false,
      features: [
        'Tudo dos planos anteriores',
        'Desenvolvimento de funcionalidades extras',
        'Inteligência artificial para atendimento',
        'Sistema de afiliados personalizado',
        'Múltiplas formas de pagamento',
        'Análise de concorrência trimestral',
        'Tráfego pago ilimitado',
        'Gestão completa de redes sociais',
        'Criação de landing pages',
        'Consultoria estratégica semanal',
        '3 meses de garantia estendida'
      ],
      color: 'green'
    }
  ];

  const handleContactClick = (planName: string) => {
    const message = `Olá! Tenho interesse no ${planName} da Avanço Digital. Gostaria de receber uma proposta personalizada.`;
    const whatsAppUrl = `https://wa.me/5511999999999?text=${encodeURIComponent(message)}`;
    window.open(whatsAppUrl, '_blank');
  };

  const getColorClasses = (color: string, type: 'bg' | 'border' | 'text') => {
    const colors = {
      gray: {
        bg: 'bg-gray-600',
        border: 'border-gray-200',
        text: 'text-gray-600'
      },
      blue: {
        bg: 'bg-blue-600',
        border: 'border-blue-200',
        text: 'text-blue-600'
      },
      green: {
        bg: 'bg-green-600',
        border: 'border-green-200',
        text: 'text-green-600'
      }
    };
    return colors[color as keyof typeof colors][type];
  };

  return (
    <section id="planos" className="py-12 sm:py-16 lg:py-20 bg-gradient-to-br from-gray-50 via-white to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12 sm:mb-16">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 mb-4 sm:mb-6">
            Nossos <span className="text-blue-700">Planos</span>
          </h2>
          <p className="text-lg sm:text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed mb-6 sm:mb-8 px-4">
            Escolha o plano ideal para transformar seu negócio. Todos incluem criação completa, 
            tráfego pago, conteúdo e suporte especializado.
          </p>
          
          {/* Value Proposition */}
          <div className="bg-orange-50 border border-orange-200 rounded-xl p-4 sm:p-6 max-w-2xl mx-auto">
            <div className="flex items-center justify-center gap-3 mb-3">
              <Shield className="text-orange-600 flex-shrink-0" size={20} />
              <span className="text-orange-800 font-semibold text-base sm:text-lg">Garantia de Satisfação</span>
            </div>
            <p className="text-orange-700 text-sm sm:text-base">
              30 dias para ver resultados ou seu dinheiro de volta
            </p>
          </div>
        </div>

        {/* Plans Grid */}
        <div className="grid lg:grid-cols-3 gap-6 sm:gap-8 mb-12 sm:mb-16">
          {plans.map((plan, index) => (
            <div key={index} className={`relative bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 hover:scale-105 ${
              plan.popular ? 'ring-2 ring-blue-500 ring-offset-2 sm:ring-offset-4' : ''
            }`}>
              {/* Popular Badge */}
              {plan.popular && (
                <div className="absolute -top-3 sm:-top-4 left-1/2 transform -translate-x-1/2">
                  <div className="bg-blue-600 text-white px-4 sm:px-6 py-1 sm:py-2 rounded-full text-xs sm:text-sm font-semibold flex items-center gap-2">
                    <Star size={14} />
                    Mais Popular
                  </div>
                </div>
              )}

              <div className="p-6 sm:p-8">
                {/* Plan Header */}
                <div className="text-center mb-6 sm:mb-8">
                  <h3 className="text-xl sm:text-2xl font-bold text-gray-900 mb-2">{plan.name}</h3>
                  <div className={`inline-flex items-center gap-2 px-3 sm:px-4 py-1 sm:py-2 rounded-full text-xs sm:text-sm font-medium ${
                    plan.color === 'blue' ? 'bg-blue-100 text-blue-700' :
                    plan.color === 'green' ? 'bg-green-100 text-green-700' :
                    'bg-gray-100 text-gray-700'
                  }`}>
                    {plan.color === 'blue' && <TrendingUp size={14} />}
                    {plan.color === 'green' && <Zap size={14} />}
                    Cobrança {plan.period}
                  </div>
                </div>

                {/* Features List */}
                <div className="mb-6 sm:mb-8">
                  <ul className="space-y-3 sm:space-y-4">
                    {plan.features.map((feature, idx) => (
                      <li key={idx} className="flex items-start gap-3">
                        <div className={`w-4 h-4 sm:w-5 sm:h-5 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5 ${
                          plan.color === 'blue' ? 'bg-blue-100' :
                          plan.color === 'green' ? 'bg-green-100' :
                          'bg-gray-100'
                        }`}>
                          <Check className={`w-2.5 h-2.5 sm:w-3 sm:h-3 ${getColorClasses(plan.color, 'text')}`} />
                        </div>
                        <span className="text-gray-600 text-xs sm:text-sm leading-relaxed">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* CTA Button */}
                <button
                  onClick={() => handleContactClick(plan.name)}
                  className={`w-full py-3 sm:py-4 px-6 rounded-xl font-semibold text-base sm:text-lg transition-all duration-300 hover:scale-105 flex items-center justify-center gap-3 ${
                    plan.popular 
                      ? 'bg-blue-600 hover:bg-blue-700 text-white shadow-lg' 
                      : 'bg-gray-100 hover:bg-gray-200 text-gray-700 border border-gray-200'
                  }`}
                >
                  <MessageCircle size={18} />
                  <span className="text-sm sm:text-base">Solicitar Proposta</span>
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Custom Plan CTA */}
        <div className="bg-gradient-to-r from-blue-600 to-teal-600 rounded-2xl p-6 sm:p-8 lg:p-12 text-center text-white mb-12 sm:mb-16">
          <h3 className="text-2xl sm:text-3xl font-bold mb-4">
            Precisa de algo personalizado?
          </h3>
          <p className="text-lg sm:text-xl text-blue-100 mb-6 sm:mb-8 max-w-2xl mx-auto px-4">
            Fale com um especialista para montar o plano ideal para sua empresa. 
            Sem compromisso, apenas uma conversa para entender suas necessidades.
          </p>
          <button
            onClick={() => handleContactClick('Plano Personalizado')}
            className="bg-white text-blue-600 hover:bg-gray-50 px-6 sm:px-8 py-3 sm:py-4 rounded-full font-semibold text-base sm:text-lg transition-all duration-300 hover:scale-105 flex items-center gap-3 mx-auto shadow-lg"
          >
            <MessageCircle size={18} />
            <span className="text-sm sm:text-base">Solicitar proposta personalizada</span>
          </button>
        </div>

        {/* Additional Info */}
        <div className="text-center">
          <div className="bg-white rounded-xl shadow-lg p-6 sm:p-8 max-w-4xl mx-auto">
            <h4 className="text-xl sm:text-2xl font-bold text-gray-900 mb-6">
              Todos os planos incluem:
            </h4>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
              <div className="text-center">
                <div className="bg-blue-100 w-10 h-10 sm:w-12 sm:h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Check className="text-blue-600" size={20} />
                </div>
                <p className="text-gray-700 font-medium text-sm sm:text-base">Setup Completo</p>
              </div>
              <div className="text-center">
                <div className="bg-green-100 w-10 h-10 sm:w-12 sm:h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                  <TrendingUp className="text-green-600" size={20} />
                </div>
                <p className="text-gray-700 font-medium text-sm sm:text-base">Otimização Contínua</p>
              </div>
              <div className="text-center">
                <div className="bg-orange-100 w-10 h-10 sm:w-12 sm:h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                  <MessageCircle className="text-orange-600" size={20} />
                </div>
                <p className="text-gray-700 font-medium text-sm sm:text-base">Suporte Dedicado</p>
              </div>
              <div className="text-center">
                <div className="bg-purple-100 w-10 h-10 sm:w-12 sm:h-12 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Shield className="text-purple-600" size={20} />
                </div>
                <p className="text-gray-700 font-medium text-sm sm:text-base">Garantia Total</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Plans;