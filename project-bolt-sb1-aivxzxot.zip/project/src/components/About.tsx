import React from 'react';
import { CheckCircle, Award, Target, Users } from 'lucide-react';

const About = () => {
  return (
    <section id="quem-somos" className="py-12 sm:py-16 lg:py-20 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12 sm:mb-16">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 mb-4 sm:mb-6">
            Quem <span className="text-blue-700">Somos</span>
          </h2>
          <p className="text-lg sm:text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed px-4">
            Dois especialistas apaixonados por transformar negócios locais em verdadeiros impérios digitais
          </p>
        </div>

        {/* Founders Grid */}
        <div className="grid lg:grid-cols-2 gap-8 lg:gap-16 mb-12 sm:mb-20">
          {/* Pedro Emanuel */}
          <div className="bg-white rounded-2xl shadow-xl overflow-hidden hover:shadow-2xl transition-all duration-300 hover:scale-105">
            <div className="aspect-w-16 aspect-h-12 bg-gradient-to-br from-blue-600 to-teal-600">
              <img
                src="https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop"
                alt="Pedro Emanuel - Especialista em E-commerce"
                className="w-full h-64 sm:h-80 object-cover object-center"
              />
            </div>
            <div className="p-6 sm:p-8">
              <div className="mb-4">
                <h3 className="text-xl sm:text-2xl font-bold text-gray-900 mb-2">Pedro Emanuel</h3>
                <p className="text-blue-600 font-semibold text-base sm:text-lg">Especialista em E-commerce & Estrutura Digital</p>
              </div>
              <p className="text-gray-600 leading-relaxed mb-6 text-sm sm:text-base">
                Ajudo empresas locais a criarem presença digital forte e escalável. 
                Cuido da criação da loja virtual completa e estratégias para atrair clientes reais. 
                Com mais de 5 anos transformando negócios offline em máquinas de vendas online.
              </p>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <CheckCircle className="text-green-500 flex-shrink-0" size={18} />
                  <span className="text-gray-700 text-sm sm:text-base">Criação de lojas virtuais otimizadas</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle className="text-green-500 flex-shrink-0" size={18} />
                  <span className="text-gray-700 text-sm sm:text-base">Estruturação completa do negócio digital</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle className="text-green-500 flex-shrink-0" size={18} />
                  <span className="text-gray-700 text-sm sm:text-base">Automação de processos de venda</span>
                </div>
              </div>
            </div>
          </div>

          {/* Partner */}
          <div className="bg-white rounded-2xl shadow-xl overflow-hidden hover:shadow-2xl transition-all duration-300 hover:scale-105">
            <div className="aspect-w-16 aspect-h-12 bg-gradient-to-br from-orange-500 to-red-600">
              <img
                src="https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop"
                alt="Especialista em Tráfego e Marketing"
                className="w-full h-64 sm:h-80 object-cover object-center"
              />
            </div>
            <div className="p-6 sm:p-8">
              <div className="mb-4">
                <h3 className="text-xl sm:text-2xl font-bold text-gray-900 mb-2">Marcus Silva</h3>
                <p className="text-orange-600 font-semibold text-base sm:text-lg">Especialista em Tráfego & Marketing Digital</p>
              </div>
              <p className="text-gray-600 leading-relaxed mb-6 text-sm sm:text-base">
                Especialista em conteúdo, anúncios e posicionamento estratégico. 
                Faço sua marca ser vista pelas pessoas certas no momento certo. 
                Domino as principais plataformas de anúncios e criação de conteúdo que converte.
              </p>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <CheckCircle className="text-green-500 flex-shrink-0" size={18} />
                  <span className="text-gray-700 text-sm sm:text-base">Gestão de tráfego pago otimizado</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle className="text-green-500 flex-shrink-0" size={18} />
                  <span className="text-gray-700 text-sm sm:text-base">Criação de conteúdo persuasivo</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle className="text-green-500 flex-shrink-0" size={18} />
                  <span className="text-gray-700 text-sm sm:text-base">Posicionamento de marca estratégico</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Company Values */}
        <div className="bg-white rounded-2xl shadow-lg p-6 sm:p-8 lg:p-12">
          <div className="text-center mb-8 sm:mb-12">
            <h3 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-4">Por que escolher a Avanço Digital?</h3>
            <p className="text-base sm:text-lg text-gray-600 max-w-2xl mx-auto px-4">
              Combinamos expertise técnica com visão estratégica para entregar resultados reais
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-6 sm:gap-8">
            <div className="text-center">
              <div className="bg-blue-100 w-12 h-12 sm:w-16 sm:h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="text-blue-600" size={24} />
              </div>
              <h4 className="text-lg sm:text-xl font-semibold text-gray-900 mb-3">Expertise Comprovada</h4>
              <p className="text-gray-600 text-sm sm:text-base px-2">
                Anos de experiência transformando negócios locais em referências digitais
              </p>
            </div>
            
            <div className="text-center">
              <div className="bg-orange-100 w-12 h-12 sm:w-16 sm:h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Target className="text-orange-600" size={24} />
              </div>
              <h4 className="text-lg sm:text-xl font-semibold text-gray-900 mb-3">Foco em Resultados</h4>
              <p className="text-gray-600 text-sm sm:text-base px-2">
                Cada estratégia é pensada para gerar vendas reais e crescimento sustentável
              </p>
            </div>
            
            <div className="text-center">
              <div className="bg-teal-100 w-12 h-12 sm:w-16 sm:h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="text-teal-600" size={24} />
              </div>
              <h4 className="text-lg sm:text-xl font-semibold text-gray-900 mb-3">Atendimento Personalizado</h4>
              <p className="text-gray-600 text-sm sm:text-base px-2">
                Cada cliente tem um especialista dedicado para seu tipo de negócio
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;